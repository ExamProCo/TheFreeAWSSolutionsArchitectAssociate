module.exports = {
  full_name: {
    presence: {allowEmpty: false},
  },
  organization: {
  },
  email: {
    presence: {allowEmpty: false},
    email: true
  },
  phone: {
  },
  customer_type: {
    presence: {allowEmpty: false},
    inclusion: {
      within: {
        "nausicaan" : "Nausicaan",
        "orion": "Orion",
        "cardassian" : "Cardassian",
        "federation" : "Federation"
      }
    }
  },
  inquiry: {
    presence: {allowEmpty: false},
    inclusion: {
      within: {
        "buy" : "I want to buy something",
        "sell": "I want to sell something",
        "transport" : "I want to transport something",
        "co-venture" : "I have a co-venture business opportunity"
      }
    }
  },
  message: {
    presence: {allowEmpty: false}
  }
}

